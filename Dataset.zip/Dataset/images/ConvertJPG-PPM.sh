#! /bin/sh
# ConvertBMP-PPM.sh script
# do chmod u+x ConvertBMP-PPM.sh to give executable permission

for filename in *.jpg
do
ppmfile=${filename%.*}.ppm

if [ ! \( -f $ppmfile \) ]
then
echo conversion de $filename en $ppmfile
convert $filename ppm/$ppmfile
fi

done

#--------- EXIT --------------
#-----------------------------

echo "  "Duree $SECONDS secondes
echo ""
#-----------------------------
