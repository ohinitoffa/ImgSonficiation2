Audio and Image Dataset for Image Sonification
================================================

Created By
----------

Ohini Kafui Toffa
Université de Montréal

Version 1.0

aeroplane,
bicycle, 
bird, 
boat, 
bottle, 
bus,
car, 
cat, 
chair, 
cow, 
diningtable, 
dog, 
horse, 
motorbike,
person, 
pottedplant, 
sheep, 
sofa, 
train, 
tv